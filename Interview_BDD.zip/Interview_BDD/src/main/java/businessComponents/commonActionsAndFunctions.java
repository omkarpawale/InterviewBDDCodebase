package businessComponents;

import java.time.Duration;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageObjects.commonUIMap;

public class commonActionsAndFunctions {
	WebDriver driver;
	Properties properties;
	
	public Logger logger = LogManager.getLogger("logger");
	public commonActionsAndFunctions(WebDriver driver, Properties properties) {
        this.driver = driver;
        this.properties = properties;
       
    }
	public boolean waitUntilElementLocated(By by, long timeoutInSeconds) {
		try {
			(new WebDriverWait(driver,Duration.ofSeconds(timeoutInSeconds))).
			until(ExpectedConditions.presenceOfElementLocated(by));
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}
	public boolean waitUntilElementLocated(WebElement by, long timeoutInSeconds) {
		try {
			(new WebDriverWait(driver,Duration.ofSeconds(timeoutInSeconds))).
			until(ExpectedConditions.elementToBeClickable(by));
			return true;
		}
		catch (Exception e) {
			return false;
		}
	}

	
	public void click(By byElement, long timeoutInSeconds, String strElementName, String strPageName) {
		
		if(waitUntilElementLocated(byElement,timeoutInSeconds)) {
			driver.findElement(byElement).click();
			logger.info(strElementName+" element clicked on page "+strPageName);
		}
		else {
			logger.error(strElementName+" Element not found on page "+ strPageName);
		}
	}
	
	public void sendKeys(By byElement,long timeoutInSeconds,String value, String strElementName, String strPageName) {
		if(waitUntilElementLocated(byElement,timeoutInSeconds)) {
			driver.findElement(byElement).sendKeys(value);
			logger.info(value+" value has been sent on element "+strElementName+" on page "+strPageName);
		}
		else {
			logger.error(strElementName+" Element not found on page "+ strPageName);
		}
	}
	
	public String getValue(By byElement,long timeoutInSeconds) {
		if(waitUntilElementLocated(byElement,timeoutInSeconds)) {
			
			return driver.findElement(byElement).getAttribute("value");
		}
		else {
			logger.error("Element not found on page");
			return null;
		}
	}
	
	public String getText(By byElement,long timeoutInSeconds) {
		if(waitUntilElementLocated(byElement,timeoutInSeconds)) {
			
			return driver.findElement(byElement).getText();
		}
		else {
			logger.error("Element not found on page");
			return null;
		}
	}
	
	public String getText(WebElement byElement,long timeoutInSeconds) {
		if(waitUntilElementLocated(byElement,timeoutInSeconds)) {
			
			return byElement.getText();
		}
		else {
			logger.error("Element not found on page");
			return null;
		}
	}
	
	public void clear(By byElement,long timeoutInSeconds) {
		if(waitUntilElementLocated(byElement,timeoutInSeconds)) {
			driver.findElement(byElement).clear();
		}
		else {
			logger.error("Element not found on page");
		}
	}
	
	public void selectFromDropDown(By byElement, long timeoutInSeconds, String strValue, String strElementName, String strPageName) {
		if(waitUntilElementLocated(byElement, timeoutInSeconds)) {
			Select selectFacility = new Select(driver.findElement(byElement));
			selectFacility.selectByVisibleText(strValue);
			logger.info(strValue+" is selected from "+strElementName+" dropdown on page "+strPageName);
		}
		else {
			logger.error(" Element not found on page ");
		}
	}
	
	public boolean verifyAppointData(String strLabel, String strValue,long timeOutInSeconds) {
		if(waitUntilElementLocated(new commonUIMap(strLabel,strValue).txtLabelWithValue, timeOutInSeconds)) {
			logger.info("Appoint label "+strLabel+" with value "+strValue+" is Displayed");
			return true;
		}else {
			logger.error(strLabel+" data NOT found");
			return false;
		}
	}
	
}
