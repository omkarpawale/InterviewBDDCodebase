package businessComponents;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.asynchttpclient.util.Assertions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import pageObjects.commonUIMap;

public class commonFunctions extends commonActionsAndFunctions {
	//WebDriver driver;
	long timeOutInSeconds = 15;
	commonUIMap objcommonUIMap = new commonUIMap();
	
	  public commonFunctions(WebDriver driver, Properties properties) {
		  	super(driver,properties);
	        
	  }
	  

	public void invoke(String strUrl,String strTitle) {
		driver.get(strUrl);
		
		driver.manage().window().maximize();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		(new WebDriverWait(driver,Duration.ofSeconds(timeOutInSeconds))).
		until(ExpectedConditions.titleIs(strTitle)); 
		
//		test.info("webpage visible with title: "+strTitle);
		
	}

	public void creatingAppointment() {
		click(objcommonUIMap.btnMakeAppointment, timeOutInSeconds, "Make Appointment", "HomePage");
		String strUserName = getValue(objcommonUIMap.txtDemoUserName, timeOutInSeconds);
		String strPassword = getValue(objcommonUIMap.txtDemoPassword, timeOutInSeconds);
		sendKeys(new commonUIMap("Username").inputFormByPlaceholder, timeOutInSeconds, strUserName, "UserName", "Login");
		sendKeys(new commonUIMap("Password").inputFormByPlaceholder, timeOutInSeconds, strPassword, "UserName", "Login");
		click(new commonUIMap("Login").btnWithText, timeOutInSeconds, "Login button", "Login");
		
		if(waitUntilElementLocated(objcommonUIMap.headerMakeAppointment, timeOutInSeconds)){
//			test.info("User "+strUserName+" logged in");
		}

		selectFromDropDown(objcommonUIMap.selectFacility, timeOutInSeconds, properties.getProperty("Facility"),
				"Facility", "Make appointment");
		click(new commonUIMap(properties.getProperty("HealthcareProgram")).btnRadioWithValue, timeOutInSeconds, "Healthcare Program radio button", "Make appointment");
		sendKeys(objcommonUIMap.visitDatePicker, timeOutInSeconds, properties.getProperty("VisitDate"), "Date", "Make appointment");
		sendKeys(new commonUIMap("comment").textAreaWithName, timeOutInSeconds,properties.getProperty("Comment"), "Comment", "Make appointment");
		click(new commonUIMap("Book Appointment").btnWithText, timeOutInSeconds, "Book Appointment button",
				"Make appointment");
	}

	public boolean verifyAppointmentCreated() {
		if (verifyAppointData("Facility", properties.getProperty("Facility"), timeOutInSeconds) &&
		verifyAppointData("Healthcare Program", properties.getProperty("HealthcareProgram"), timeOutInSeconds) &&
		verifyAppointData("Visit Date", properties.getProperty("VisitDate"), timeOutInSeconds) &&
		verifyAppointData("Comment", properties.getProperty("Comment"), timeOutInSeconds)) {
//			test.pass("Appointment is booked with \n"+"Facility: "+properties.getProperty("Facility")+"\nHealthcare Program: "+properties.getProperty("HealthcareProgram")+
//					"\nVisit Date: "+properties.getProperty("VisitDate")+"\nComment: "+properties.getProperty("Comment"));
			System.out.println("Appointment is booked with \n"+"Facility: "+properties.getProperty("Facility")+"\nHealthcare Program: "+properties.getProperty("HealthcareProgram")+
					"\nVisit Date: "+properties.getProperty("VisitDate")+"\nComment: "+properties.getProperty("Comment"));
		return true;
		}
		else {
//			test.fail("Appoint is bokked with incorrect data");
			return false;
		}
		
		
	}
	public void logOut() {
		click(objcommonUIMap.ellipsis, timeOutInSeconds, "ellipsis Button", "Logout");
		click(objcommonUIMap.txtLogout, timeOutInSeconds, "Logout Button", "Logout");
//		test.info("User logged out");
	}

	public boolean verifyTableVisible() {
		return waitUntilElementLocated(objcommonUIMap.table, timeOutInSeconds);
	}
	public File downloadDataInExcel() {
		click(objcommonUIMap.btnExcel, timeOutInSeconds, "Excel Button", "Datatable download");
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String filePath = System.getProperty("user.dir")+"//src//test//resources//Downloads//"+properties.getProperty("fileName")+".xlsx";
		File excelFile = new File(filePath);

		if (!excelFile.exists()) {
			System.out.println("Excel file not found.");
			driver.quit();
			return null;
		}
		else {
			return excelFile;
		}
		
	}

	public boolean verifyData(File excelFile) throws IOException {
		FileInputStream fis = new FileInputStream(excelFile);
		Workbook workbook = new XSSFWorkbook(fis);
		Sheet sheet = workbook.getSheetAt(0);

		Row headerRow = sheet.getRow(0);
		List<String> columnNames = new ArrayList<>();
		for (Cell cell : headerRow) {
			columnNames.add(cell.getStringCellValue().trim());
		}
		int i,verifyAll=1;
		for ( i = 1; i <= sheet.getLastRowNum(); i++) { //this loop will take ROW from Excel
			Row row = sheet.getRow(i);
			List<String> excelRowValue = new ArrayList<String>();
			for (int j = 0; j < row.getLastCellNum(); j++) {

				Cell cell = row.getCell(j);
				String cellValue;
				if (cell.getCellType() == CellType.STRING) {
					cellValue = cell.getStringCellValue().trim();
				} else if (cell.getCellType() == CellType.NUMERIC) {
					cellValue = String.valueOf((int) cell.getNumericCellValue()).trim();
				} else {
					cellValue = "";
				}

				if (j == 0) { // FirstName going to search
					clear(objcommonUIMap.inputSearch, timeOutInSeconds);
					sendKeys(objcommonUIMap.inputSearch, timeOutInSeconds, cellValue, "First Name", "Data Table");
				}

				excelRowValue.add(j, cellValue);
			}

			List<WebElement> resultRows = driver.findElements(objcommonUIMap.tableRows);
			String flag = "not Found";
			while (!flag.equalsIgnoreCase("Found")) {
				for (WebElement resultRow : resultRows) {

					List<WebElement> tableData = resultRow.findElements(By.tagName("td"));
//					System.out.println(excelRowValue.size());
					int start;
					for (int num = 0; num < excelRowValue.size(); num++) {
//						System.out.println(excelRowValue.get(num)+" is compared with "+getText(tableData.get(num), timeOutInSeconds));
						if (excelRowValue.get(num).equalsIgnoreCase(getText(tableData.get(num), timeOutInSeconds))) {
							//System.out.println(excelRowValue.get(num));
							start = num;
						} else {
							break;
						}

						if (start == excelRowValue.size()-1) {
							flag = "Found";
							System.out.println(excelRowValue+" verified from Excel to Website");
//							test.pass(excelRowValue+" verified from Excel to Website");
							verifyAll++;
						}

					}
				}
			}

		}
		workbook.close();
		if(excelFile.delete()) {
//			test.info("File is deleted");
		}
		
		if (i==verifyAll) {
			return true;
		}
		else {
			return false;
		}

	}

	

}
