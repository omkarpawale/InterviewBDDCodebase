package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;

public class commonUIMap {
	
	public By btnMakeAppointment,btnExcel;
	public By txtDemoUserName, txtDemoPassword,txtConfirmation,txtLabelWithValue,txtLogout;
	public By headerMakeAppointment;
	public By inputFormByPlaceholder, btnWithText,btnRadioWithValue,inputSearch;
	public By selectFacility,visitDatePicker,textAreaWithName,ellipsis;
	public By table,tableRows;
	
	
	public commonUIMap(){
		
		btnMakeAppointment= By.id("btn-make-appointment");
		headerMakeAppointment = By.xpath("//section[@id='appointment']//*[text()='Make Appointment']");
		txtDemoUserName=By.xpath("//*[@aria-describedby='demo_username_label']");
		txtDemoPassword=By.xpath("//*[@aria-describedby='demo_password_label']");
		selectFacility= By.id("combo_facility");
		visitDatePicker = By.xpath("//input[@name='visit_date' and @id='txt_visit_date']");
		txtConfirmation =By.xpath("//section[@id='summary']//*[text()='Appointment Confirmation']");
		btnExcel = By.cssSelector("a.buttons-excel");
		inputSearch= By.xpath("//input[@type='search']");
		
		tableRows = By.xpath("//table//tbody//tr");
		ellipsis = By.id("menu-toggle");
		txtLogout = By.linkText("Logout");
		table = By.xpath("//table[@id='example']");
		
		
	}
	public commonUIMap(String strValue) {
		inputFormByPlaceholder = By.xpath("//label[text()='"+strValue+"']/..//input[@placeholder='"+strValue+"']");
		btnWithText= By.xpath("//button[text()='"+strValue+"']");
		btnRadioWithValue = By.xpath("//*[@type='radio' and @value='"+strValue+"']");
		textAreaWithName= By.xpath("//textarea[@name='"+strValue+"']");
		
	}
	public commonUIMap(String strKey,String strValue) {
		txtLabelWithValue = By.xpath("//label[text()='"+strKey+"']/parent::div//following-sibling::div//*[text()='"+strValue+"']");
	}
	
}
