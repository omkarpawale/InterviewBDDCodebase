package stepDefinitions;

import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;

import businessComponents.commonFunctions;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import testScripts.baseTest;

public class VerifyDataAndAppointmentSteps {

	public WebDriver driver;
    public Properties properties;
    public commonFunctions objcommonFunctions;
    private baseTest baseTestObj;

    @Before
    public void setUp() {
        baseTestObj = new baseTest(); 
        this.driver = baseTestObj.getDriver();
        this.properties = baseTestObj.getProperties();
        this.objcommonFunctions = new commonFunctions(driver, properties);
    }
    @Given("the user is on the application table page")
    public void user_on_table_page() {
        objcommonFunctions.invoke(properties.getProperty("verifyFileURL"), properties.getProperty("verifyFileURLTitle"));
    }

    @When("the user verifies the table visible on webPage")
    public void user_verifies_table_visible() {
       
    	assertTrue(objcommonFunctions.verifyTableVisible());
    }

    @Then("the data from excel and over web should be matched")
    public void data_should_be_correct() {
       
    	 try {
    		 assertTrue(objcommonFunctions.verifyData(objcommonFunctions.downloadDataInExcel()));
         } catch (IOException e) {
             e.printStackTrace();
         }
       
    }

    @Given("the user is on the appointment creation page")
    public void user_on_appointment_page() {
       
        objcommonFunctions.invoke(properties.getProperty("appointmentURL"), properties.getProperty("appointmentURLTitle"));
    }

    @When("the user creates an appointment")
    public void user_creates_appointment() {
       
        objcommonFunctions.creatingAppointment();
    }

    @Then("the appointment should be successfully created")
    public void appointment_successfully_created() {
    	assertTrue(objcommonFunctions.verifyAppointmentCreated());
        objcommonFunctions.logOut();
    }
    
    @After
    public void tearDown() {
		
		if (driver != null) {
			driver.quit();
		}
	}
}
