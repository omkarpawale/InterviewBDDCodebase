package testScripts;

import org.testng.annotations.AfterMethod;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import businessComponents.commonFunctions;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.dynamic.loading.ClassLoadingStrategy.Configurable;

public class baseTest {
	public Properties properties = new Properties();
	public WebDriver driver;
	
	
	public  baseTest() {
		
		WebDriverManager.chromedriver().setup();
		Map<String, Object> prefs = new HashMap<>();
		prefs.put("download.default_directory", System.getProperty("user.dir") + "//src//test//resources//Downloads");
		prefs.put("download.prompt_for_download", false);
		ChromeOptions options = new ChromeOptions();
		options.setExperimentalOption("prefs", prefs);
		options.addArguments("--remote-allow-origins=*");
		driver = new ChromeDriver(options);

		try (InputStream input = Configurable.class.getClassLoader().getResourceAsStream("globalData.Properties")) {
			if (input == null) {
				System.out.println("unable to find globalData.Properties");
				return;
			}
			properties.load(input);
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}
	
	public WebDriver getDriver() {
		return driver;
	}
	
	public Properties getProperties() {
		return properties;
	}

	
	
	
}
